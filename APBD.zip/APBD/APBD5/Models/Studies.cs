﻿namespace APBD5.Models
{
    public class Studies
    {
        public int IdStudies { get; set; }
        public string Name { get; set; }
    }
}
