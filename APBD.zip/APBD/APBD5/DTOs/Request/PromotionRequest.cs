﻿namespace APBD5.DTOs.RequestModels
{
    public class PromotionRequest
    {
        public string Studies { get; set; }
        public int Semester { get; set; }
    }
}
