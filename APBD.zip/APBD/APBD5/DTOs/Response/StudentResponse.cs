﻿using System;

namespace APBD5.DTOs.ResponseModels
{
    public class StudentResponse
    {
        public string IndexNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
